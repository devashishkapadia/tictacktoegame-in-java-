/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictokboard;

import java.util.Scanner;

/**
 *
 * @author devashish kapadia
 */
public class Tictokboard {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
      board  game = new board();
      game.draw();
      System.out.println("Enter the value of Row");
      int row = input.nextInt();
      System.out.println("Enter the value of col");
      int col = input.nextInt();
     game.Place(marker.x, row, col);
     game.draw();
     System.out.println("Enter the value of Row");
      int bow = input.nextInt();
      System.out.println("Enter the value of col");
      int low = input.nextInt();
     game.Place(marker.o, bow, low);
      game.draw();
      
        
    }
    
}
