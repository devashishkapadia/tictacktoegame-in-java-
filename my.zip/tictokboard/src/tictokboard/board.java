/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictokboard;

/**
 *
 * @author devashish kapadia
 */
public class board {
    
    public marker[][] board;
    
    public board (){
        this.board = new marker[3][3];
        this.clear();
    }
    public board (marker[][] theboard){
        this.board =theboard;
    }
    
    public final void clear(){
        for(int i = 0 ; i < 3; i++){
            for(int j = 0 ; j < 3 ; j++){
                this.board[i][j] = marker.Empty;
            }
        }
    }
public void draw(){
    System.out.printf("\n  0 1 2\n");
    for (int i = 0 ; i< 3 ; i++){
        System.out.printf("%d", i);
        for (int j =0 ; j < 3 ; j++){
            if (j < 2){
               System.out.printf("%s|", board[i][j]);  
            }else{
                System.out.printf("%s", board[i][j]);
            }
        }
   System.out.printf("\n ");
   if (i < 2) System.out.printf("-+-+-\n");
    }
    
} 

public boolean Place(marker Marker, int row , int col) {
   if ( this.board[row][col] == marker.Empty){
       this.board[row][col]= Marker;
        return true ;
   }else{
        return false;
   }
   
}

}
