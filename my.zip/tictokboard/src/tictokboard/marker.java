/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictokboard;

/**
 *
 * @author devashish kapadia
 */
public enum marker {
   x('x'),o('o'),Empty(' ');
   
   private char ch;

 marker (char ch){
     this.ch = ch;
}
@Override 
        public String toString(){
    return String.format("%c", this.ch);
}
 
}
